<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLessonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lessons', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->enum('content_type', ['video', 'text', 'file', 'quiz']);
            $table->string('content_url')->nullable();
            $table->integer('sort_order')->default(0);
               $table->integer('duration')->nullable(); // duration in minutes
            $table->boolean('is_preview')->default(false);
            $table->boolean('is_time_locked')->default(false);
            $table->date('start_date')->nullable();
            $table->time('start_time')->nullable();
            $table->integer('unlock_day_after_purchase')->nullable();
            $table->text('description')->nullable();
            $table->longText('content')->nullable();
            $table->json('files')->nullable();
            $table->foreignId('section_id')->constrained('sections')->cascadeOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lessons');
    }
}
