<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCertificatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('certificates', function (Blueprint $table) {
            $table->id();
               $table->unsignedBigInteger('enrollment_id')->unique();
    $table->string('certificate_code')->unique();
    $table->timestamp('issued_at')->useCurrent();
    $table->string('pdf_url')->nullable();
    $table->timestamps();

    $table->foreign('enrollment_id')->references('id')->on('enrollments')->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('certificates');
    }
}
