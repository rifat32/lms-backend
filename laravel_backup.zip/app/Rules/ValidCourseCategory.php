<?php

namespace App\Rules;

use App\Models\CourseCategory;
use Illuminate\Contracts\Validation\Rule;

class ValidCourseCategory implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        // Check if the CourseCategory exists
        return CourseCategory::where('id', $value)->exists();
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The selected course category is invalid.';
    }
}
