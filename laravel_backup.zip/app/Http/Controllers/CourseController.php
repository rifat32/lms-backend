<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\CourseRequest;
use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * @OA\Tag(
 *     name="Courses",
 *     description="Endpoints for managing courses"
 * )
 */
class CourseController extends Controller
{
    /**
     * @OA\Get(
     *     path="/v1.0/courses",
     *     tags={"course"},
     *     operationId="getCourses",
     *     summary="Get all courses",
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="category_id",
     *         in="query",
     *         required=false,
     *         description="Filter by category ID",
     *         @OA\Schema(type="integer", example=1)
     *     ),
     *     @OA\Parameter(
     *         name="searchKey",
     *         in="query",
     *         required=false,
     *         description="Search by keyword in title or description",
     *         @OA\Schema(type="string", example="Laravel")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="List of courses",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Courses retrieved successfully"),
     *             @OA\Property(
     *                 property="data",
     *                 type="array",
     *                 @OA\Items(
     *                     @OA\Property(property="id", type="integer", example=1),
     *                     @OA\Property(property="title", type="string", example="Laravel Basics"),
     *                     @OA\Property(property="description", type="string", example="Learn Laravel framework"),
     *                     @OA\Property(property="price", type="number", format="float", example=49.99),
     *                     @OA\Property(property="category_id", type="integer", example=1),
     *                     @OA\Property(property="created_at", type="string", format="date-time", example="2025-09-19T12:00:00Z"),
     *                     @OA\Property(property="updated_at", type="string", format="date-time", example="2025-09-19T12:00:00Z")
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Bad Request",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Invalid query parameters")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Unauthenticated.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Forbidden",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="You do not have permission to access this resource.")
     *         )
     *     )
     * )
     */

    public function getCourses(Request $request)
    {


          $query = Course::filters();

        $courses = retrieve_data($query, 'created_at', 'courses');

        // SEND RESPONSE
        return response()->json([
            'success' => true,
            'message' => 'Courses retrieved successfully',
            'meta' => $courses['meta'],
            'data' => $courses['data'],
        ], 200);


    }

    /**
     * @OA\Get(
     *     path="/v1.0/courses/{id}",
     *     tags={"course"},
     *     operationId="getCourseById",
     *     summary="Get a single course by ID",
     *     description="Retrieve a course by its ID along with lessons, FAQs, and notices",
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="Course ID",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Course details retrieved successfully",
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Course retrieved successfully"),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="id", type="integer", example=1),
     *                 @OA\Property(property="name", type="string", example="Introduction to Programming"),
     *                 @OA\Property(property="description", type="string", example="A beginner course on programming"),
     *                 @OA\Property(
     *                     property="lessons",
     *                     type="array",
     *                     @OA\Items(
     *                         type="object",
     *                         @OA\Property(property="id", type="integer", example=1),
     *                         @OA\Property(property="title", type="string", example="Lesson 1")
     *                     )
     *                 ),
     *                 @OA\Property(
     *                     property="faqs",
     *                     type="array",
     *                     @OA\Items(
     *                         type="object",
     *                         @OA\Property(property="id", type="integer", example=1),
     *                         @OA\Property(property="question", type="string", example="What is a variable?"),
     *                         @OA\Property(property="answer", type="string", example="A variable is...")
     *                     )
     *                 ),
     *                 @OA\Property(
     *                     property="notices",
     *                     type="array",
     *                     @OA\Items(
     *                         type="object",
     *                         @OA\Property(property="id", type="integer", example=1),
     *                         @OA\Property(property="title", type="string", example="Exam Notice"),
     *                         @OA\Property(property="description", type="string", example="Exam will be held on...")
     *                     )
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Course not found",
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Course not found")
     *         )
     *     )
     * )
     */

    public function getCourseById($id)
    {
        // FIND BY ID
        $course = Course::with(
            [
                "sections.lessons"
            
            ]
            
            )->find($id);

        // SEND RESPONSE
        if (empty($course)) {
            return response()->json([
                'success' => false,
                'message' => 'Course not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Course retrieved successfully',
            'data' => $course
        ], 200);
    }

    /**
     * @OA\Post(
     *     path="/v1.0/courses",
     *     tags={"course"},
     *     operationId="createCourse",
     *     summary="Create a new course (Admin only)",
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"title","description","category_id"},
     *             @OA\Property(property="title", type="string", example="Laravel Basics"),
     *             @OA\Property(property="description", type="string", example="Learn Laravel framework"),
     *             @OA\Property(property="price", type="number", format="float", example=49.99),
     *             @OA\Property(property="category_id", type="integer", example=1),
     *             @OA\Property(property="lecturer_id", type="integer", example=2),
     *             @OA\Property(property="is_free", type="boolean", example=false),
     *             @OA\Property(property="status", type="string", enum={"draft","published","archived"}, example="draft"),
     *             @OA\Property(property="duration_days", type="integer", example=30)
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Course created successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="id", type="integer", example=10),
     *             @OA\Property(property="title", type="string", example="Laravel Basics"),
     *             @OA\Property(property="description", type="string", example="Learn Laravel framework"),
     *             @OA\Property(property="price", type="number", format="float", example=49.99),
     *             @OA\Property(property="category_id", type="integer", example=1),
     *             @OA\Property(property="lecturer_id", type="integer", example=2),
     *             @OA\Property(property="is_free", type="boolean", example=false),
     *             @OA\Property(property="status", type="string", example="draft"),
     *             @OA\Property(property="duration_days", type="integer", example=30),
     *             @OA\Property(property="created_at", type="string", format="date-time", example="2025-09-18T12:00:00Z"),
     *             @OA\Property(property="updated_at", type="string", format="date-time", example="2025-09-18T12:00:00Z")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Unauthenticated.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Forbidden",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="You do not have permission to perform this action.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Not Found",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Category not found.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=409,
     *         description="Conflict",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="A course with this title already exists.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="The title field is required."),
     *             @OA\Property(property="errors", type="object",
     *                 @OA\Property(property="title", type="array",
     *                     @OA\Items(type="string", example="The title field is required.")
     *                 ),
     *                 @OA\Property(property="description", type="array",
     *                     @OA\Items(type="string", example="The description field is required.")
     *                 ),
     *                 @OA\Property(property="category_id", type="array",
     *                     @OA\Items(type="string", example="The category id field is required.")
     *                 ),
     *                 @OA\Property(property="lecturer_id", type="array",
     *                     @OA\Items(type="string", example="The lecturer id field is required.")
     *                 )
     *             )
     *         )
     *     )
     * )
     */



    public function createCourse(CourseRequest $request)
    {
        try {
            DB::beginTransaction();
            // VALIDATE PAYLOAD
            $request_payload = $request->validated();

            // ADD CREATED BY
            $request_payload['created_by'] = auth()->user()->id;

            // CREATE
            $course = Course::create($request_payload);

            // COMMIT TRANSACTION
            DB::commit();
            // SEND RESPONSE
            return response()->json([
                'success' => true,
                'message' => 'Course created successfully',
                'data' => $course
            ], 201);
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * @OA\Put(
     *     path="/v1.0/courses",
     *     tags={"course"},
     *     operationId="updateCourse",
     *     summary="Update a course (Admin only)",
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"title","description","category_id", "id"},
     *             @OA\Property(property="id", type="integer", example=10),
     *             @OA\Property(property="title", type="string", example="Updated Title"),
     *             @OA\Property(property="description", type="string", example="Updated description"),
     *             @OA\Property(property="price", type="number", format="float", example=59.99),
     *             @OA\Property(property="category_id", type="integer", example=2),
     *             @OA\Property(property="lecturer_id", type="integer", example=3),
     *             @OA\Property(property="is_free", type="boolean", example=false),
     *             @OA\Property(property="status", type="string", enum={"draft","published","archived"}, example="published"),
     *             @OA\Property(property="duration_days", type="integer", example=45)
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Course updated successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="id", type="integer", example=10),
     *             @OA\Property(property="title", type="string", example="Updated Title"),
     *             @OA\Property(property="description", type="string", example="Updated description"),
     *             @OA\Property(property="price", type="number", format="float", example=59.99),
     *             @OA\Property(property="category_id", type="integer", example=2),
     *             @OA\Property(property="lecturer_id", type="integer", example=3),
     *             @OA\Property(property="is_free", type="boolean", example=false),
     *             @OA\Property(property="status", type="string", example="published"),
     *             @OA\Property(property="duration_days", type="integer", example=45),
     *             @OA\Property(property="updated_at", type="string", format="date-time", example="2025-09-19T12:00:00Z")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Unauthenticated.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Forbidden",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="You do not have permission to perform this action.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Course not found",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Course not found.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=409,
     *         description="Conflict",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="A course with this title already exists.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="The title field is required."),
     *             @OA\Property(property="errors", type="object",
     *                 @OA\Property(property="title", type="array",
     *                     @OA\Items(type="string", example="The title field is required.")
     *                 ),
     *                 @OA\Property(property="description", type="array",
     *                     @OA\Items(type="string", example="The description field is required.")
     *                 ),
     *                 @OA\Property(property="category_id", type="array",
     *                     @OA\Items(type="string", example="The category id field is required.")
     *                 ),
     *                 @OA\Property(property="lecturer_id", type="array",
     *                     @OA\Items(type="string", example="The lecturer id field is required.")
     *                 )
     *             )
     *         )
     *     )
     * )
     */


    public function updateCourse(CourseRequest $request)
    {

        try {
            DB::beginTransaction();
            // VALIDATE PAYLOAD
            $request_payload = $request->validated();

            // FIND BY ID
            $course = Course::find($request_payload['id']);

            // SEND RESPONSE
            if (empty($course)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Course not found'
                ], 404);
            }

            // UPDATE
            $course->update($request_payload);

            // COMMIT TRANSACTION
            DB::commit();
            // SEND RESPONSE
            return response()->json([
                'success' => true,
                'message' => 'Course updated successfully',
                'data' => $course
            ], 200);
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}
