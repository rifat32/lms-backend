<?php

return [
    "permissions" => [
        'admin'
    ]
];
