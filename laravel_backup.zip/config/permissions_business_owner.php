<?php

return [
    "permissions" => [
        'owner',

        "business_update",
        "business_view",
    ]
];
