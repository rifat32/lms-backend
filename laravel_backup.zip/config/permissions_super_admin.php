<?php

return [
    "permissions" => [
        'super_admin',

        "user_create",
        "user_update",
        "user_view",
        "user_delete",

        "role_create",
        "role_update",
        "role_view",
        "role_delete",

        "business_create",
        "business_update",
        "business_view",
        "business_delete",
    ]
];
