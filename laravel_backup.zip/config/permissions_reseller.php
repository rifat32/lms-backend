<?php

return [
    "permissions" => [
        'reseller'
    ]
];
