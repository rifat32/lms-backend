<?php

return [
  "permissions" => [
    'student'
  ]
];
