<?php


return [

    "roles" => ['admin', 'lecturer', 'student']
];
