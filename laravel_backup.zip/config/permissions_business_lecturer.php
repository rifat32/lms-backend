<?php

return [
    "permissions" => [
        'lecturer'
    ]
];
