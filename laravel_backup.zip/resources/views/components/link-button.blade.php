<div class="col-md-3">
    <a href="{{ $link }}" class="btn btn-{{ $type }} w-100" target="_blank">
        {{ $label }}
    </a>
</div>
